CREATE TABLE public.tienda_estado (
  user_id UUID NOT NULL PRIMARY KEY,
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tienda_estado TO authenticated;
GRANT ALL ON public.tienda_estado TO service_role;
ALTER TABLE public.tienda_estado ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Cada usuario ve y edita su tienda" ON public.tienda_estado FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
ALTER TABLE public.tienda_estado REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tienda_estado;