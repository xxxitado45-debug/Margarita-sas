CREATE TABLE public.tienda_acceso (
  owner_id uuid NOT NULL,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (owner_id, email)
);
GRANT SELECT, INSERT, DELETE ON public.tienda_acceso TO authenticated;
GRANT ALL ON public.tienda_acceso TO service_role;
ALTER TABLE public.tienda_acceso ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Dueño gestiona accesos" ON public.tienda_acceso FOR ALL TO authenticated
  USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "Invitado ve su acceso" ON public.tienda_acceso FOR SELECT TO authenticated
  USING (lower(email) = lower(auth.jwt() ->> 'email'));

CREATE OR REPLACE FUNCTION public.puede_ver_tienda(_owner uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT auth.uid() = _owner OR EXISTS (
    SELECT 1 FROM public.tienda_acceso
    WHERE owner_id = _owner AND lower(email) = lower(auth.jwt() ->> 'email')
  )
$$;

DROP POLICY "Cada usuario ve y edita su tienda" ON public.tienda_estado;
CREATE POLICY "Dueño e invitados ven y editan la tienda" ON public.tienda_estado FOR ALL TO authenticated
  USING (public.puede_ver_tienda(user_id)) WITH CHECK (public.puede_ver_tienda(user_id));