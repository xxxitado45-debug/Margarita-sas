import { useSyncExternalStore } from "react";

export type Producto = {
  id: string;
  nombre: string;
  emoji: string;
  precio: number;
  costo: number;
  stock: number;
  minimo: number;
};

export type TipoMov = "venta" | "gasto" | "retiro" | "ingreso";

export type Movimiento = {
  id: string;
  tipo: TipoMov;
  descripcion: string;
  monto: number; // siempre positivo
  costo: number; // costo de mercancía (solo ventas)
  fecha: string; // ISO
  pago?: Pago; // solo ventas
};

export type Pago = "efectivo" | "transferencia";

export type GastoFijo = {
  id: string;
  nombre: string;
  monto: number;
  dia: number; // día del mes en que vence
  pagos: Record<string, string>; // "2026-10" -> id del movimiento
};

export type Apunte = { id: string; tipo: "fiado" | "abono"; descripcion: string; monto: number; fecha: string };
export type Cliente = { id: string; nombre: string; telefono: string; apuntes: Apunte[] };
export const deuda = (c: Cliente) => c.apuntes.reduce((s, a) => s + (a.tipo === "fiado" ? a.monto : -a.monto), 0);

type Estado = { negocio: string; productos: Producto[]; movimientos: Movimiento[]; fijos?: GastoFijo[]; clientes?: Cliente[] };

export const mesClave = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;

const KEY = "tienda-carretera-v1";
const NOMBRE = "margarita.sas";
const uid = () => Math.random().toString(36).slice(2, 10);

const semilla: Estado = {
  negocio: NOMBRE,
  productos: [
    { id: "p1", nombre: "Gaseosa 400 ml", emoji: "🥤", precio: 3000, costo: 1800, stock: 24, minimo: 6 },
    { id: "p2", nombre: "Agua 600 ml", emoji: "💧", precio: 2000, costo: 900, stock: 30, minimo: 8 },
    { id: "p3", nombre: "Chocolatina", emoji: "🍫", precio: 2500, costo: 1400, stock: 4, minimo: 6 },
    { id: "p4", nombre: "Galletas", emoji: "🍪", precio: 1500, costo: 800, stock: 18, minimo: 5 },
    { id: "p5", nombre: "Café tinto", emoji: "☕", precio: 1500, costo: 400, stock: 50, minimo: 10 },
    { id: "p6", nombre: "Empanada", emoji: "🥟", precio: 2500, costo: 1200, stock: 3, minimo: 5 },
  ],
  movimientos: [],
};

let estado: Estado = semilla;
let cargado = false;
const subs = new Set<() => void>();
const notificar = () => subs.forEach((s) => s());

function cargar() {
  if (cargado || typeof window === "undefined") return;
  cargado = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) estado = JSON.parse(raw);
  } catch {
    /* ignorar */
  }
  if (estado.negocio === "La Parada") estado = { ...estado, negocio: NOMBRE };
}

// ---- Sincronización en la nube (todos los dispositivos) ----
const DISPOSITIVO = uid();
let usuario: string | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;

async function subir() {
  if (!usuario) return;
  const { supabase } = await import("@/integrations/supabase/client");
  await supabase.from("tienda_estado").upsert({
    user_id: usuario,
    data: { ...estado, _origen: DISPOSITIVO } as never,
    updated_at: new Date().toISOString(),
  });
}

export let tiendaDe: { dueño: string; propia: boolean } | null = null;

export async function conectarNube(miId: string, miEmail?: string) {
  const { supabase } = await import("@/integrations/supabase/client");
  cargar();
  let userId = miId;
  if (miEmail) {
    const { data: acc } = await (supabase as any).from("tienda_acceso").select("owner_id").ilike("email", miEmail).limit(1);
    if (acc?.[0]?.owner_id) userId = acc[0].owner_id;
  }
  tiendaDe = { dueño: userId, propia: userId === miId };
  notificar();
  usuario = userId;
  const { data } = await supabase.from("tienda_estado").select("data").eq("user_id", userId).maybeSingle();
  if (data?.data && Object.keys(data.data as object).length) {
    estado = data.data as unknown as Estado;
    if (estado.negocio === "La Parada") estado = { ...estado, negocio: NOMBRE };
    localStorage.setItem(KEY, JSON.stringify(estado));
    notificar();
  } else {
    await subir(); // primera vez: sube lo que había en este dispositivo
  }
  const canal = supabase
    .channel(`tienda-${userId}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "tienda_estado", filter: `user_id=eq.${userId}` }, (p) => {
      const d = (p.new as { data?: Estado & { _origen?: string } })?.data;
      if (!d || d._origen === DISPOSITIVO) return;
      estado = d;
      localStorage.setItem(KEY, JSON.stringify(estado));
      notificar();
    })
    .subscribe();
  return () => {
    usuario = null;
    supabase.removeChannel(canal);
  };
}

function set(fn: (e: Estado) => Estado) {
  cargar();
  estado = fn(estado);
  localStorage.setItem(KEY, JSON.stringify(estado));
  notificar();
  if (timer) clearTimeout(timer);
  timer = setTimeout(subir, 400);
}

export function useStore() {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => {
      cargar();
      return estado;
    },
    () => semilla,
  );
}

export const acciones = {
  guardarProducto(p: Omit<Producto, "id"> & { id?: string }) {
    set((e) => ({
      ...e,
      productos: p.id
        ? e.productos.map((x) => (x.id === p.id ? { ...x, ...p, id: x.id } : x))
        : [...e.productos, { ...p, id: uid() }],
    }));
  },
  borrarProducto(id: string) {
    set((e) => ({ ...e, productos: e.productos.filter((p) => p.id !== id) }));
  },
  reponer(id: string, cantidad: number, costoTotal: number) {
    set((e) => {
      const p = e.productos.find((x) => x.id === id);
      return {
        ...e,
        productos: e.productos.map((x) => (x.id === id ? { ...x, stock: x.stock + cantidad } : x)),
        movimientos: costoTotal > 0
          ? [{ id: uid(), tipo: "gasto", descripcion: `Compra — ${cantidad} × ${p?.nombre ?? ""}`, monto: costoTotal, costo: 0, fecha: new Date().toISOString() }, ...e.movimientos]
          : e.movimientos,
      };
    });
  },
  vender(pago: Pago, carrito: Record<string, number>) {
    set((e) => {
      let monto = 0, costo = 0, unidades = 0;
      const productos = e.productos.map((p) => {
        const q = carrito[p.id] ?? 0;
        if (!q) return p;
        monto += q * p.precio;
        costo += q * p.costo;
        unidades += q;
        return { ...p, stock: Math.max(0, p.stock - q) };
      });
      if (!unidades) return e;
      const nombres = e.productos.filter((p) => carrito[p.id]).map((p) => p.nombre);
      return {
        ...e,
        productos,
        movimientos: [
          { id: uid(), tipo: "venta", descripcion: `Venta — ${unidades} ${unidades === 1 ? "producto" : "productos"} (${nombres.slice(0, 2).join(", ")}${nombres.length > 2 ? "…" : ""})`, monto, costo, pago, fecha: new Date().toISOString() },
          ...e.movimientos,
        ],
      };
    });
  },
  registrar(tipo: TipoMov, descripcion: string, monto: number) {
    set((e) => ({
      ...e,
      movimientos: [{ id: uid(), tipo, descripcion, monto, costo: 0, fecha: new Date().toISOString() }, ...e.movimientos],
    }));
  },
  borrarMovimiento(id: string) {
    set((e) => ({
      ...e,
      movimientos: e.movimientos.filter((m) => m.id !== id),
      fijos: (e.fijos ?? []).map((f) => ({
        ...f,
        pagos: Object.fromEntries(Object.entries(f.pagos).filter(([, v]) => v !== id)),
      })),
    }));
  },
  guardarFijo(f: { id?: string; nombre: string; monto: number; dia: number }) {
    set((e) => {
      const fijos = e.fijos ?? [];
      return {
        ...e,
        fijos: f.id
          ? fijos.map((x) => (x.id === f.id ? { ...x, ...f, id: x.id } : x))
          : [...fijos, { ...f, id: uid(), pagos: {} }],
      };
    });
  },
  borrarFijo(id: string) {
    set((e) => ({ ...e, fijos: (e.fijos ?? []).filter((f) => f.id !== id) }));
  },
  pagarFijo(id: string, mes: string) {
    set((e) => {
      const f = (e.fijos ?? []).find((x) => x.id === id);
      if (!f || f.pagos[mes]) return e;
      const mov: Movimiento = { id: uid(), tipo: "gasto", descripcion: `Gasto fijo — ${f.nombre}`, monto: f.monto, costo: 0, fecha: new Date().toISOString() };
      return {
        ...e,
        movimientos: [mov, ...e.movimientos],
        fijos: (e.fijos ?? []).map((x) => (x.id === id ? { ...x, pagos: { ...x.pagos, [mes]: mov.id } } : x)),
      };
    });
  },
  guardarCliente(c: { id?: string; nombre: string; telefono: string }) {
    let nuevoId = c.id ?? uid();
    set((e) => {
      const cs = e.clientes ?? [];
      return {
        ...e,
        clientes: c.id ? cs.map((x) => (x.id === c.id ? { ...x, ...c, id: x.id } : x)) : [...cs, { ...c, id: nuevoId, apuntes: [] }],
      };
    });
    return nuevoId;
  },
  borrarCliente(id: string) {
    set((e) => ({ ...e, clientes: (e.clientes ?? []).filter((c) => c.id !== id) }));
  },
  apuntar(clienteId: string, tipo: "fiado" | "abono", descripcion: string, monto: number) {
    set((e) => {
      const c = (e.clientes ?? []).find((x) => x.id === clienteId);
      if (!c) return e;
      const a: Apunte = { id: uid(), tipo, descripcion, monto, fecha: new Date().toISOString() };
      return {
        ...e,
        clientes: (e.clientes ?? []).map((x) => (x.id === clienteId ? { ...x, apuntes: [a, ...x.apuntes] } : x)),
        movimientos: tipo === "abono"
          ? [{ id: uid(), tipo: "ingreso", descripcion: `Abono fiado — ${c.nombre}`, monto, costo: 0, fecha: a.fecha }, ...e.movimientos]
          : e.movimientos,
      };
    });
  },
  borrarApunte(clienteId: string, apunteId: string) {
    set((e) => ({
      ...e,
      clientes: (e.clientes ?? []).map((x) => (x.id === clienteId ? { ...x, apuntes: x.apuntes.filter((a) => a.id !== apunteId) } : x)),
    }));
  },
  renombrar(negocio: string) {
    set((e) => ({ ...e, negocio }));
  },
  async cargarInventarioMargarita() {
    const { inventarioMargarita } = await import("./inventario-margarita");
    set((e) => {
      const nombres = new Set(inventarioMargarita.map((p) => p.nombre.toLowerCase()));
      // quita los productos de ejemplo y conserva los que agregaste tú
      const propios = e.productos.filter((p) => !p.id.startsWith("m")).filter((p) => !/^p\d$/.test(p.id) && p.nombre !== "Hhu" && !nombres.has(p.nombre.toLowerCase()));
      const viejos = new Map(e.productos.map((p) => [p.id, p]));
      return { ...e, productos: [...inventarioMargarita.map((p) => ({ ...p, stock: viejos.get(p.id)?.stock ?? p.stock, costo: viejos.get(p.id)?.costo ?? 0 })), ...propios] };
    });
  },
};

export const dinero = (n: number) =>
  "$" + Math.round(n).toLocaleString("es-CO");

export const esHoy = (iso: string) => new Date(iso).toDateString() === new Date().toDateString();

export const hora = (iso: string) =>
  new Date(iso).toLocaleTimeString("es-CO", { hour: "numeric", minute: "2-digit" });

export function resumen(movs: Movimiento[]) {
  let ventas = 0, costo = 0, gastos = 0, retiros = 0, ingresos = 0, tickets = 0, transferencias = 0;
  for (const m of movs) {
    if (m.tipo === "venta") { ventas += m.monto; costo += m.costo; tickets++; if (m.pago === "transferencia") transferencias += m.monto; }
    if (m.tipo === "gasto") gastos += m.monto;
    if (m.tipo === "retiro") retiros += m.monto;
    if (m.tipo === "ingreso") ingresos += m.monto;
  }
  return { ventas, costo, gastos, retiros, ingresos, tickets, transferencias, efectivo: ventas - transferencias, ganancia: ventas - costo - gastos, caja: ventas - transferencias + ingresos - gastos - retiros };
}
