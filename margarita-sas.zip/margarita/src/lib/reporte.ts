import { dinero, hora, resumen, type Movimiento } from "./store";

export const claveDia = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export const movsDelDia = (movs: Movimiento[], dia: string) => movs.filter((m) => claveDia(new Date(m.fecha)) === dia);

export const fechaLarga = (dia: string) => {
  const [y = 2000, m = 1, d = 1] = dia.split("-").map(Number);
  const s = new Date(y, m - 1, d).toLocaleDateString("es-CO", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  return s.charAt(0).toUpperCase() + s.slice(1);
};

const tipoTxt = { venta: "Venta", gasto: "Gasto", retiro: "Retiro", ingreso: "Ingreso" };

export async function descargarPdf(negocio: string, dia: string, movs: Movimiento[]) {
  const { jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");
  const r = resumen(movs);
  const doc = new jsPDF();
  doc.setFontSize(20);
  doc.text(negocio, 14, 18);
  doc.setFontSize(11);
  doc.text(`Reporte del día — ${fechaLarga(dia)}`, 14, 26);

  autoTable(doc, {
    startY: 32,
    theme: "plain",
    styles: { fontSize: 11 },
    body: [
      ["Ventas", dinero(r.ventas)],
      ["  · en efectivo", dinero(r.efectivo)],
      ["  · por transferencia", dinero(r.transferencias)],
      ["Costo de mercancía", "-" + dinero(r.costo)],
      ["Gastos", "-" + dinero(r.gastos)],
      ["Ganancia", dinero(r.ganancia)],
      ["Retiros", dinero(r.retiros)],
      ["Otros ingresos", dinero(r.ingresos)],
      ["Efectivo esperado en caja", dinero(r.caja)],
      ["Número de ventas", String(r.tickets)],
    ],
    columnStyles: { 1: { halign: "right", fontStyle: "bold" } },
  });

  autoTable(doc, {
    startY: (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8,
    head: [["Hora", "Tipo", "Detalle", "Valor"]],
    body: [...movs].reverse().map((m) => [hora(m.fecha), tipoTxt[m.tipo], m.descripcion, (m.tipo === "venta" || m.tipo === "ingreso" ? "+" : "-") + dinero(m.monto)]),
    headStyles: { fillColor: [232, 89, 12] },
    columnStyles: { 3: { halign: "right" } },
    styles: { fontSize: 9 },
  });

  doc.save(`${negocio}-${dia}.pdf`);
}
