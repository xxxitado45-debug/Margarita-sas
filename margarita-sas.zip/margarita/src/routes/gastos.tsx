import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ListaMovs, Pantalla } from "@/components/tienda";
import { acciones, useStore, type TipoMov } from "@/lib/store";

export const Route = createFileRoute("/gastos")({
  head: () => ({
    meta: [
      { title: "Gastos y movimientos — margarita.sas" },
      { name: "description", content: "Registra gastos, retiros e ingresos de caja." },
      { property: "og:title", content: "Gastos y movimientos — margarita.sas" },
      { property: "og:description", content: "Registra gastos, retiros e ingresos de caja." },
    ],
  }),
  component: Gastos,
});

const tipos: { k: TipoMov; label: string; ayuda: string }[] = [
  { k: "gasto", label: "Gasto", ayuda: "Hielo, luz, transporte, proveedor…" },
  { k: "retiro", label: "Retiro", ayuda: "Dinero que sacas de la caja" },
  { k: "ingreso", label: "Ingreso", ayuda: "Fondo de cambio u otro ingreso" },
];
const rapidos = ["Hielo", "Bolsas", "Transporte", "Luz", "Proveedor"];

function Gastos() {
  const { movimientos } = useStore();
  const [tipo, setTipo] = useState<TipoMov>("gasto");
  const [desc, setDesc] = useState("");
  const [monto, setMonto] = useState(0);
  const lista = movimientos.filter((m) => m.tipo !== "venta").slice(0, 30);
  const t = tipos.find((x) => x.k === tipo)!;

  return (
    <Pantalla titulo="Gastos" sub="Anota todo lo que entra y sale">
      <div className="tile mt-5 space-y-3 p-5">
        <div className="grid grid-cols-3 gap-2">
          {tipos.map((x) => (
            <button key={x.k} onClick={() => setTipo(x.k)} className={`rounded-full py-2 text-sm font-bold ${tipo === x.k ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
              {x.label}
            </button>
          ))}
        </div>
        <input className="field" placeholder={t.ayuda} value={desc} onChange={(e) => setDesc(e.target.value)} />
        {tipo === "gasto" && (
          <div className="flex flex-wrap gap-2">
            {rapidos.map((r) => (
              <button key={r} onClick={() => setDesc(r)} className="rounded-full bg-secondary px-3 py-1 text-xs font-bold">{r}</button>
            ))}
          </div>
        )}
        <input className="field text-2xl font-bold" type="number" inputMode="numeric" placeholder="$ 0" value={monto || ""} onChange={(e) => setMonto(Number(e.target.value))} />
        <button
          disabled={!desc.trim() || monto <= 0}
          onClick={() => { acciones.registrar(tipo, `${t.label} — ${desc.trim()}`, monto); setDesc(""); setMonto(0); }}
          className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40"
        >
          Registrar {t.label.toLowerCase()}
        </button>
      </div>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Últimos registros</h2>
        <ListaMovs movs={lista} borrar />
      </section>
    </Pantalla>
  );
}
