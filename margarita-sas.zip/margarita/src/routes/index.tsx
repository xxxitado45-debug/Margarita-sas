import { createFileRoute, Link } from "@tanstack/react-router";
import { Pantalla, VentaRapida, ListaMovs } from "@/components/tienda";
import { AccesoCompartido } from "@/components/acceso";
import { dinero, esHoy, resumen, useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Panel — margarita.sas" },
      { name: "description", content: "Ventas, ganancia, inventario y caja del día de tu tienda de carretera." },
      { property: "og:title", content: "Panel — margarita.sas" },
      { property: "og:description", content: "Ventas, ganancia, inventario y caja del día en un solo lugar." },
    ],
  }),
  component: Panel,
});

function Panel() {
  const { negocio, productos, movimientos } = useStore();
  const hoy = movimientos.filter((m) => esHoy(m.fecha));
  const r = resumen(hoy);
  const bajos = productos.filter((p) => p.stock <= p.minimo);
  const fecha = new Date().toLocaleDateString("es-CO", { weekday: "long", day: "numeric", month: "long" });

  return (
    <Pantalla titulo={negocio} sub={fecha.charAt(0).toUpperCase() + fecha.slice(1)}>
      <div className="mt-5 rounded-[20px] bg-primary p-5 text-primary-foreground">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Ventas de hoy</p>
        <p className="mt-1 text-[44px] font-extrabold leading-none">{dinero(r.ventas)}</p>
        <div className="mt-4 flex items-end justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Ganancia</p>
            <p className="text-xl font-bold leading-none">{r.ganancia >= 0 ? "+" : "–"}{dinero(Math.abs(r.ganancia))}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Tickets</p>
            <p className="text-xl font-bold leading-none">{r.tickets}</p>
          </div>
        </div>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Link to="/calendario" className="tile py-3 text-center text-sm font-bold">📅 Calendario</Link>
        <Link to="/dia" search={{}} className="tile py-3 text-center text-sm font-bold">🖨️ Reporte de hoy</Link>
      </div>
      <button
        onClick={async () => { const { supabase } = await import("@/integrations/supabase/client"); await supabase.auth.signOut(); }}
        className="mt-2 w-full text-right text-xs font-medium text-muted-foreground"
      >
        Cerrar sesión
      </button>


      <section className="mt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Venta rápida</h2>
          <span className="text-xs font-medium text-muted-foreground">Toca para cobrar</span>
        </div>
        <VentaRapida limite={4} />
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Poco stock</h2>
        {bajos.length === 0 ? (
          <p className="mt-1 text-sm text-muted-foreground">Todo bien surtido 👍</p>
        ) : (
          <>
            <p className="mt-1 text-sm font-medium text-muted-foreground">Toca para reponer</p>
            <div className="mt-4 space-y-3">
              {bajos.map((p) => (
                <div key={p.id} className="tile flex items-center gap-3 rounded-[20px] p-4">
                  <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-destructive/15 text-lg">{p.emoji}</div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-bold leading-tight">{p.nombre}</p>
                    <p className="text-sm font-medium text-destructive">{p.stock} restantes</p>
                  </div>
                  <Link to="/inventario" className="shrink-0 rounded-full bg-destructive px-4 py-2 text-sm font-bold text-destructive-foreground">Pedir</Link>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Caja del día</h2>
        <ListaMovs movs={hoy.slice(0, 6)} />
      </section>
      <AccesoCompartido />
    </Pantalla>
  );
}
