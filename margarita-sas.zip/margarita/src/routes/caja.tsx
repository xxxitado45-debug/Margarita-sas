import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ListaMovs, Pantalla } from "@/components/tienda";
import { dinero, resumen, useStore, type Movimiento } from "@/lib/store";

export const Route = createFileRoute("/caja")({
  head: () => ({
    meta: [
      { title: "Caja y contabilidad — margarita.sas" },
      { name: "description", content: "Ingresos, gastos, ganancia y efectivo en caja por periodo." },
      { property: "og:title", content: "Caja y contabilidad — margarita.sas" },
      { property: "og:description", content: "Ingresos, gastos, ganancia y efectivo en caja por periodo." },
    ],
  }),
  component: Caja,
});

const periodos = { hoy: "Hoy", semana: "7 días", mes: "Este mes", todo: "Todo" } as const;
type P = keyof typeof periodos;

function filtrar(movs: Movimiento[], p: P) {
  const ahora = new Date();
  return movs.filter((m) => {
    const d = new Date(m.fecha);
    if (p === "hoy") return d.toDateString() === ahora.toDateString();
    if (p === "semana") return ahora.getTime() - d.getTime() < 7 * 864e5;
    if (p === "mes") return d.getMonth() === ahora.getMonth() && d.getFullYear() === ahora.getFullYear();
    return true;
  });
}

function Caja() {
  const { movimientos } = useStore();
  const [p, setP] = useState<P>("hoy");
  const movs = filtrar(movimientos, p);
  const r = resumen(movs);
  const filas = [
    ["Ventas", r.ventas, "text-success"],
    ["💵 Efectivo", r.efectivo, "text-success"],
    ["📲 Transferencia", r.transferencias, "text-success"],
    ["Costo de mercancía vendida", -r.costo, "text-muted-foreground"],
    ["Gastos", -r.gastos, "text-destructive"],
  ] as const;

  return (
    <Pantalla titulo="Caja" sub="Contabilidad del negocio">
      <div className="mt-5 flex gap-2 overflow-x-auto">
        {(Object.keys(periodos) as P[]).map((k) => (
          <button key={k} onClick={() => setP(k)} className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold ${p === k ? "bg-ink text-paper" : "bg-card text-muted-foreground"}`}>
            {periodos[k]}
          </button>
        ))}
      </div>

      <div className="tile mt-5 p-5">
        {filas.map(([l, v, c]) => (
          <div key={l} className="flex justify-between py-1.5 text-sm">
            <span className="font-medium">{l}</span>
            <span className={`font-bold ${c}`}>{v < 0 ? "–" : ""}{dinero(Math.abs(v))}</span>
          </div>
        ))}
        <div className="mt-2 flex items-end justify-between border-t border-border pt-3">
          <span className="font-display text-lg font-semibold">Ganancia</span>
          <span className={`text-3xl font-extrabold ${r.ganancia >= 0 ? "text-success" : "text-destructive"}`}>
            {r.ganancia < 0 ? "–" : ""}{dinero(Math.abs(r.ganancia))}
          </span>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between rounded-[22px] bg-ink px-5 py-4">
        <div>
          <p className="text-sm font-medium text-paper/70">Efectivo esperado en caja</p>
          <p className="text-xs text-paper/50">ventas en efectivo + ingresos − gastos − retiros</p>
        </div>
        <span className="text-2xl font-extrabold text-paper">{dinero(r.caja)}</span>
      </div>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Movimientos ({movs.length})</h2>
        <ListaMovs movs={movs} borrar />
      </section>
    </Pantalla>
  );
}
