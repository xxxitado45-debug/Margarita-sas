import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pantalla } from "@/components/tienda";
import { acciones, dinero, useStore, type Producto } from "@/lib/store";

export const Route = createFileRoute("/inventario")({
  head: () => ({
    meta: [
      { title: "Inventario — margarita.sas" },
      { name: "description", content: "Productos, precios, costos y existencias de tu tienda." },
      { property: "og:title", content: "Inventario — margarita.sas" },
      { property: "og:description", content: "Productos, precios, costos y existencias de tu tienda." },
    ],
  }),
  component: Inventario,
});

type Form = Omit<Producto, "id"> & { id?: string };
const vacio: Form = { nombre: "", emoji: "📦", precio: 0, costo: 0, stock: 0, minimo: 5 };

function Inventario() {
  const { productos } = useStore();
  const [form, setForm] = useState<Form | null>(null);
  const [reponer, setReponer] = useState<Producto | null>(null);
  const valor = productos.reduce((s, p) => s + p.stock * p.costo, 0);

  return (
    <Pantalla titulo="Inventario" sub={`${productos.length} productos · valor ${dinero(valor)}`}>
      <button onClick={() => setForm(vacio)} className="mt-5 w-full rounded-[22px] bg-primary py-4 text-lg font-bold text-primary-foreground">
        + Agregar producto
      </button>
      {!productos.some((p) => p.id === "m1" && p.precio > 0 && productos.some((q) => q.id === "m9" && q.precio > 0)) && (
        <button
          onClick={() => { if (confirm("¿Cargar los productos de las hojas de Refresquería Margarita? Se quitan los productos de ejemplo.")) acciones.cargarInventarioMargarita(); }}
          className="mt-3 w-full rounded-[22px] bg-ink py-4 text-lg font-bold text-paper"
        >
          📋 Cargar inventario de las hojas
        </button>
      )}

      <div className="mt-5 space-y-3">
        {productos.map((p) => {
          const bajo = p.stock <= p.minimo;
          return (
            <div key={p.id} className="tile flex items-center gap-3 rounded-[20px] p-4">
              <div className={`grid size-11 shrink-0 place-items-center rounded-xl text-xl ${bajo ? "bg-destructive/15" : "bg-secondary"}`}>{p.emoji}</div>
              <button className="min-w-0 flex-1 text-left" onClick={() => setForm(p)}>
                <p className="truncate font-bold leading-tight">{p.nombre}</p>
                <p className="text-sm text-muted-foreground">
                  {dinero(p.precio)} · costo {dinero(p.costo)}
                </p>
                <p className={`text-sm font-bold ${bajo ? "text-destructive" : "text-success"}`}>{p.stock} en stock</p>
              </button>
              <button onClick={() => setReponer(p)} className="shrink-0 rounded-full bg-ink px-4 py-2 text-sm font-bold text-paper">+ Stock</button>
            </div>
          );
        })}
      </div>

      {form && <FormProducto inicial={form} cerrar={() => setForm(null)} />}
      {reponer && <FormReponer p={reponer} cerrar={() => setReponer(null)} />}
    </Pantalla>
  );
}

function Hoja({ titulo, cerrar, children }: { titulo: string; cerrar: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end bg-ink/40" onClick={cerrar}>
      <div className="mx-auto w-full max-w-[480px] rounded-t-[28px] bg-background p-5 pb-8" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold">{titulo}</h2>
          <button onClick={cerrar} className="text-xl text-muted-foreground">✕</button>
        </div>
        <div className="mt-4 space-y-3">{children}</div>
      </div>
    </div>
  );
}

function Num({ label, value, set }: { label: string; value: number; set: (n: number) => void }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <input type="number" inputMode="numeric" min={0} className="field mt-1" value={value || ""} onChange={(e) => set(Number(e.target.value))} />
    </label>
  );
}

function FormProducto({ inicial, cerrar }: { inicial: Form; cerrar: () => void }) {
  const [f, setF] = useState(inicial);
  const up = (k: keyof Form) => (v: number | string) => setF({ ...f, [k]: v });
  return (
    <Hoja titulo={f.id ? "Editar producto" : "Nuevo producto"} cerrar={cerrar}>
      <div className="flex gap-3">
        <label className="w-20 text-sm font-medium">Ícono<input className="field mt-1 text-center" value={f.emoji} onChange={(e) => up("emoji")(e.target.value)} /></label>
        <label className="flex-1 text-sm font-medium">Nombre<input className="field mt-1" value={f.nombre} onChange={(e) => up("nombre")(e.target.value)} /></label>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Num label="Precio de venta" value={f.precio} set={up("precio")} />
        <Num label="Costo" value={f.costo} set={up("costo")} />
        <Num label="Stock" value={f.stock} set={up("stock")} />
        <Num label="Avisar con" value={f.minimo} set={up("minimo")} />
      </div>
      <button
        disabled={!f.nombre.trim()}
        onClick={() => { acciones.guardarProducto({ ...f, nombre: f.nombre.trim() }); cerrar(); }}
        className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40"
      >
        Guardar
      </button>
      {f.id && (
        <button onClick={() => { if (confirm("¿Eliminar producto?")) { acciones.borrarProducto(f.id!); cerrar(); } }} className="w-full py-2 text-sm font-bold text-destructive">
          Eliminar producto
        </button>
      )}
    </Hoja>
  );
}

function FormReponer({ p, cerrar }: { p: Producto; cerrar: () => void }) {
  const [cant, setCant] = useState(12);
  const [costo, setCosto] = useState(12 * p.costo);
  return (
    <Hoja titulo={`Reponer ${p.nombre}`} cerrar={cerrar}>
      <Num label="Unidades que llegaron" value={cant} set={(n) => { setCant(n); setCosto(n * p.costo); }} />
      <Num label="Pagado al proveedor (se registra como gasto)" value={costo} set={setCosto} />
      <button disabled={!cant} onClick={() => { acciones.reponer(p.id, cant, costo); cerrar(); }} className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40">
        Agregar al inventario
      </button>
    </Hoja>
  );
}
