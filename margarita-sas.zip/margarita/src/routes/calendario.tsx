import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Pantalla } from "@/components/tienda";
import { claveDia } from "@/lib/reporte";
import { dinero, resumen, useStore } from "@/lib/store";

export const Route = createFileRoute("/calendario")({
  head: () => ({
    meta: [
      { title: "Calendario de ventas — margarita.sas" },
      { name: "description", content: "Mira cuánto se vendió cada día del mes." },
      { property: "og:title", content: "Calendario de ventas — margarita.sas" },
      { property: "og:description", content: "Mira cuánto se vendió cada día del mes." },
    ],
  }),
  component: Calendario,
});

const corto = (n: number) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1000 ? `${Math.round(n / 1000)}k` : String(Math.round(n)));

function Calendario() {
  const { movimientos } = useStore();
  const hoy = new Date();
  const [mes, setMes] = useState(new Date(hoy.getFullYear(), hoy.getMonth(), 1));
  const y = mes.getFullYear(), m = mes.getMonth();
  const dias = new Date(y, m + 1, 0).getDate();
  const offset = (new Date(y, m, 1).getDay() + 6) % 7; // lunes primero

  const porDia: Record<string, number> = {};
  for (const mv of movimientos) if (mv.tipo === "venta") {
    const k = claveDia(new Date(mv.fecha));
    porDia[k] = (porDia[k] ?? 0) + mv.monto;
  }
  const delMes = movimientos.filter((mv) => { const d = new Date(mv.fecha); return d.getMonth() === m && d.getFullYear() === y; });
  const r = resumen(delMes);
  const max = Math.max(1, ...Array.from({ length: dias }, (_, i) => porDia[claveDia(new Date(y, m, i + 1))] ?? 0));
  const titulo = mes.toLocaleDateString("es-CO", { month: "long", year: "numeric" });

  return (
    <Pantalla titulo="Calendario" sub="Toca un día para ver su reporte">
      <div className="mt-5 flex items-center justify-between">
        <button onClick={() => setMes(new Date(y, m - 1, 1))} className="tile grid size-11 place-items-center text-xl font-bold">‹</button>
        <h2 className="text-xl font-semibold">{titulo.charAt(0).toUpperCase() + titulo.slice(1)}</h2>
        <button onClick={() => setMes(new Date(y, m + 1, 1))} className="tile grid size-11 place-items-center text-xl font-bold">›</button>
      </div>

      <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[11px] font-bold text-muted-foreground">
        {["L", "M", "M", "J", "V", "S", "D"].map((d, i) => <div key={i}>{d}</div>)}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {Array.from({ length: offset }).map((_, i) => <div key={`v${i}`} />)}
        {Array.from({ length: dias }, (_, i) => {
          const fecha = claveDia(new Date(y, m, i + 1));
          const v = porDia[fecha] ?? 0;
          const esHoy = fecha === claveDia(hoy);
          const alpha = v ? 15 + Math.round((v / max) * 60) : 0;
          return (
            <Link
              key={fecha}
              to="/dia"
              search={{ fecha }}
              className={`flex aspect-square flex-col items-center justify-center rounded-xl ${esHoy ? "ring-2 ring-primary" : ""} ${v ? "" : "bg-card"}`}
              style={v ? { backgroundColor: `color-mix(in oklab, var(--success) ${alpha}%, var(--card))` } : undefined}
            >
              <span className="text-sm font-bold">{i + 1}</span>
              {v > 0 && <span className="text-[10px] font-bold">{corto(v)}</span>}
            </Link>
          );
        })}
      </div>

      <div className="mt-5 rounded-[20px] bg-primary p-5 text-primary-foreground">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Ventas del mes</p>
        <p className="mt-1 text-[36px] font-extrabold leading-none">{dinero(r.ventas)}</p>
        <div className="mt-3 flex justify-between text-sm font-medium">
          <span>Gastos {dinero(r.gastos)}</span>
          <span>Ganancia {dinero(r.ganancia)}</span>
        </div>
      </div>
    </Pantalla>
  );
}
