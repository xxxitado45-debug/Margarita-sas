import { createFileRoute } from "@tanstack/react-router";
import { Pantalla, VentaRapida } from "@/components/tienda";

export const Route = createFileRoute("/venta")({
  head: () => ({
    meta: [
      { title: "Nueva venta — margarita.sas" },
      { name: "description", content: "Cobra ventas rápido tocando tus productos." },
      { property: "og:title", content: "Nueva venta — margarita.sas" },
      { property: "og:description", content: "Cobra ventas rápido tocando tus productos." },
    ],
  }),
  component: () => (
    <Pantalla titulo="Nueva venta" sub="Toca cada producto que lleva el cliente">
      <VentaRapida />
    </Pantalla>
  ),
});
