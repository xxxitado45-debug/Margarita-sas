import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pantalla } from "@/components/tienda";
import { acciones, dinero, mesClave, useStore, type GastoFijo } from "@/lib/store";

export const Route = createFileRoute("/mes")({
  head: () => ({
    meta: [
      { title: "Gastos fijos del mes — margarita.sas" },
      { name: "description", content: "Arriendo, luz, agua y sueldos: controla qué ya pagaste este mes." },
      { property: "og:title", content: "Gastos fijos del mes — margarita.sas" },
      { property: "og:description", content: "Controla los pagos fijos mensuales de tu tienda." },
    ],
  }),
  component: Mes,
});

type Form = { id?: string; nombre: string; monto: number; dia: number };
const sugeridos = ["Arriendo", "Luz", "Agua", "Internet", "Sueldo ayudante", "Gas"];

function Mes() {
  const { fijos = [] } = useStore();
  const [form, setForm] = useState<Form | null>(null);
  const hoy = new Date();
  const mes = mesClave(hoy);
  const nombreMes = hoy.toLocaleDateString("es-CO", { month: "long", year: "numeric" });
  const orden = [...fijos].sort((a, b) => a.dia - b.dia);
  const total = fijos.reduce((s, f) => s + f.monto, 0);
  const pagado = fijos.filter((f) => f.pagos[mes]).reduce((s, f) => s + f.monto, 0);
  const pct = total ? Math.round((pagado / total) * 100) : 0;

  const estado = (f: GastoFijo) => {
    if (f.pagos[mes]) return { t: "Pagado", c: "text-success", b: "bg-success/15" };
    if (f.dia < hoy.getDate()) return { t: `Vencido el ${f.dia}`, c: "text-destructive", b: "bg-destructive/15" };
    const faltan = f.dia - hoy.getDate();
    if (faltan <= 3) return { t: faltan === 0 ? "Vence hoy" : `Vence en ${faltan} días`, c: "text-wood", b: "bg-accent/25" };
    return { t: `Vence el ${f.dia}`, c: "text-muted-foreground", b: "bg-secondary" };
  };

  return (
    <Pantalla titulo="Gastos fijos" sub={nombreMes.charAt(0).toUpperCase() + nombreMes.slice(1)}>
      <div className="mt-5 rounded-[20px] bg-primary p-5 text-primary-foreground">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Pendiente este mes</p>
        <p className="mt-1 text-[40px] font-extrabold leading-none">{dinero(total - pagado)}</p>
        <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-primary-foreground/25">
          <div className="h-full rounded-full bg-primary-foreground transition-all" style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-2 text-sm font-medium opacity-90">Pagado {dinero(pagado)} de {dinero(total)}</p>
      </div>

      <button onClick={() => setForm({ nombre: "", monto: 0, dia: 1 })} className="mt-4 w-full rounded-[22px] bg-ink py-4 text-lg font-bold text-paper">
        + Agregar gasto fijo
      </button>

      <div className="mt-5 space-y-3">
        {orden.length === 0 && <p className="text-sm text-muted-foreground">Agrega el arriendo, la luz, el agua… y aquí verás qué falta por pagar cada mes.</p>}
        {orden.map((f) => {
          const e = estado(f);
          return (
            <div key={f.id} className="tile flex items-center gap-3 rounded-[20px] p-4">
              <div className={`grid size-11 shrink-0 place-items-center rounded-xl text-sm font-extrabold ${e.b} ${e.c}`}>{f.dia}</div>
              <button className="min-w-0 flex-1 text-left" onClick={() => setForm(f)}>
                <p className="truncate font-bold leading-tight">{f.nombre}</p>
                <p className="text-sm font-medium">{dinero(f.monto)}</p>
                <p className={`text-xs font-bold ${e.c}`}>{e.t}</p>
              </button>
              {f.pagos[mes] ? (
                <span className="shrink-0 text-2xl text-success">✓</span>
              ) : (
                <button onClick={() => acciones.pagarFijo(f.id, mes)} className="shrink-0 rounded-full bg-success px-4 py-2 text-sm font-bold text-paper">Pagar</button>
              )}
            </div>
          );
        })}
      </div>
      {orden.length > 0 && <p className="mt-4 text-xs text-muted-foreground">Al tocar "Pagar" se anota como gasto en la caja. El mes siguiente vuelven a quedar pendientes.</p>}

      {form && <FormFijo inicial={form} cerrar={() => setForm(null)} />}
    </Pantalla>
  );
}

function FormFijo({ inicial, cerrar }: { inicial: Form; cerrar: () => void }) {
  const [f, setF] = useState(inicial);
  return (
    <div className="fixed inset-0 z-30 flex items-end bg-ink/40" onClick={cerrar}>
      <div className="mx-auto w-full max-w-[480px] space-y-3 rounded-t-[28px] bg-background p-5 pb-8" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold">{f.id ? "Editar gasto fijo" : "Nuevo gasto fijo"}</h2>
          <button onClick={cerrar} className="text-xl text-muted-foreground">✕</button>
        </div>
        <input className="field" placeholder="Nombre (ej. Arriendo)" value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} />
        {!f.id && (
          <div className="flex flex-wrap gap-2">
            {sugeridos.map((s) => (
              <button key={s} onClick={() => setF({ ...f, nombre: s })} className="rounded-full bg-secondary px-3 py-1 text-xs font-bold">{s}</button>
            ))}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <label className="text-sm font-medium">Valor mensual
            <input type="number" inputMode="numeric" className="field mt-1" value={f.monto || ""} onChange={(e) => setF({ ...f, monto: Number(e.target.value) })} />
          </label>
          <label className="text-sm font-medium">Día de pago
            <input type="number" inputMode="numeric" min={1} max={31} className="field mt-1" value={f.dia || ""} onChange={(e) => setF({ ...f, dia: Math.min(31, Math.max(1, Number(e.target.value))) })} />
          </label>
        </div>
        <button
          disabled={!f.nombre.trim() || f.monto <= 0}
          onClick={() => { acciones.guardarFijo({ ...f, nombre: f.nombre.trim() }); cerrar(); }}
          className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40"
        >
          Guardar
        </button>
        {f.id && (
          <button onClick={() => { if (confirm("¿Eliminar este gasto fijo?")) { acciones.borrarFijo(f.id!); cerrar(); } }} className="w-full py-2 text-sm font-bold text-destructive">
            Eliminar
          </button>
        )}
      </div>
    </div>
  );
}
