import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pantalla } from "@/components/tienda";
import { acciones, deuda, dinero, hora, useStore, type Cliente } from "@/lib/store";

export const Route = createFileRoute("/fiado")({
  head: () => ({
    meta: [
      { title: "Cuaderno de fiado — margarita.sas" },
      { name: "description", content: "Lleva la cuenta de lo que te deben tus clientes y búscalos por nombre." },
      { property: "og:title", content: "Cuaderno de fiado — margarita.sas" },
      { property: "og:description", content: "Lleva la cuenta de lo que te deben tus clientes." },
    ],
  }),
  component: Fiado,
});

const sinTildes = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

function Fiado() {
  const { clientes = [] } = useStore();
  const [q, setQ] = useState("");
  const [abierto, setAbierto] = useState<string | null>(null);
  const [nuevo, setNuevo] = useState(false);
  const total = clientes.reduce((s, c) => s + Math.max(0, deuda(c)), 0);
  const lista = clientes
    .filter((c) => sinTildes(c.nombre).includes(sinTildes(q.trim())))
    .sort((a, b) => deuda(b) - deuda(a));
  const cliente = clientes.find((c) => c.id === abierto);

  return (
    <Pantalla titulo="Fiado" sub="Cuaderno de cuentas por cobrar">
      <div className="mt-5 rounded-[20px] bg-primary p-5 text-primary-foreground">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Te deben en total</p>
        <p className="mt-1 text-[40px] font-extrabold leading-none">{dinero(total)}</p>
        <p className="mt-2 text-sm font-medium opacity-90">{clientes.filter((c) => deuda(c) > 0).length} personas con deuda</p>
      </div>

      <input className="field mt-4" placeholder="🔍 Buscar por nombre…" value={q} onChange={(e) => setQ(e.target.value)} />
      <button onClick={() => setNuevo(true)} className="mt-3 w-full rounded-[22px] bg-ink py-4 text-lg font-bold text-paper">+ Nueva persona</button>

      <div className="mt-5 space-y-3">
        {lista.length === 0 && <p className="text-sm text-muted-foreground">{q ? "Nadie con ese nombre." : "Aún no hay nadie en el cuaderno."}</p>}
        {lista.map((c) => {
          const d = deuda(c);
          return (
            <button key={c.id} onClick={() => setAbierto(c.id)} className="tile flex w-full items-center gap-3 rounded-[20px] p-4 text-left">
              <div className="grid size-11 shrink-0 place-items-center rounded-full bg-wood text-lg font-bold text-paper">{c.nombre.charAt(0).toUpperCase()}</div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold leading-tight">{c.nombre}</p>
                <p className="text-xs text-muted-foreground">{c.apuntes[0] ? `Último: ${new Date(c.apuntes[0].fecha).toLocaleDateString("es-CO", { day: "numeric", month: "short" })}` : "Sin apuntes"}</p>
              </div>
              <span className={`text-lg font-extrabold ${d > 0 ? "text-destructive" : "text-success"}`}>{d > 0 ? dinero(d) : "Al día"}</span>
            </button>
          );
        })}
      </div>

      {nuevo && <FormCliente cerrar={(id) => { setNuevo(false); if (id) setAbierto(id); }} />}
      {cliente && <Cuenta c={cliente} cerrar={() => setAbierto(null)} />}
    </Pantalla>
  );
}

function Hoja({ children, cerrar }: { children: React.ReactNode; cerrar: () => void }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end bg-ink/40" onClick={cerrar}>
      <div className="mx-auto max-h-[90vh] w-full max-w-[480px] space-y-3 overflow-y-auto rounded-t-[28px] bg-background p-5 pb-8" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

function FormCliente({ cerrar }: { cerrar: (id?: string) => void }) {
  const [nombre, setNombre] = useState("");
  const [tel, setTel] = useState("");
  return (
    <Hoja cerrar={() => cerrar()}>
      <h2 className="text-2xl font-semibold">Nueva persona</h2>
      <input className="field" placeholder="Nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} autoFocus />
      <input className="field" placeholder="Teléfono (opcional)" inputMode="tel" value={tel} onChange={(e) => setTel(e.target.value)} />
      <button disabled={!nombre.trim()} onClick={() => cerrar(acciones.guardarCliente({ nombre: nombre.trim(), telefono: tel.trim() }))} className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40">
        Guardar
      </button>
    </Hoja>
  );
}

function Cuenta({ c, cerrar }: { c: Cliente; cerrar: () => void }) {
  const [tipo, setTipo] = useState<"fiado" | "abono">("fiado");
  const [desc, setDesc] = useState("");
  const [monto, setMonto] = useState(0);
  const d = deuda(c);

  return (
    <Hoja cerrar={cerrar}>
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-semibold">{c.nombre}</h2>
          {c.telefono && <a href={`tel:${c.telefono}`} className="text-sm font-medium text-primary">📞 {c.telefono}</a>}
        </div>
        <button onClick={cerrar} className="text-xl text-muted-foreground">✕</button>
      </div>
      <div className="flex items-center justify-between rounded-[22px] bg-ink px-5 py-4">
        <span className="text-sm font-medium text-paper/70">Debe</span>
        <span className="text-2xl font-extrabold text-paper">{dinero(Math.max(0, d))}</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => setTipo("fiado")} className={`rounded-full py-2 text-sm font-bold ${tipo === "fiado" ? "bg-destructive text-destructive-foreground" : "bg-secondary"}`}>Fiar</button>
        <button onClick={() => setTipo("abono")} className={`rounded-full py-2 text-sm font-bold ${tipo === "abono" ? "bg-success text-paper" : "bg-secondary"}`}>Abonar / pagar</button>
      </div>
      <input className="field" placeholder={tipo === "fiado" ? "¿Qué se llevó? (ej. 2 gaseosas)" : "Nota (opcional)"} value={desc} onChange={(e) => setDesc(e.target.value)} />
      <div className="flex gap-2">
        <input className="field text-xl font-bold" type="number" inputMode="numeric" placeholder="$ 0" value={monto || ""} onChange={(e) => setMonto(Number(e.target.value))} />
        {tipo === "abono" && d > 0 && <button onClick={() => setMonto(d)} className="shrink-0 rounded-[14px] bg-secondary px-3 text-sm font-bold">Todo</button>}
      </div>
      <button
        disabled={monto <= 0 || (tipo === "fiado" && !desc.trim())}
        onClick={() => { acciones.apuntar(c.id, tipo, desc.trim() || "Abono", monto); setDesc(""); setMonto(0); }}
        className={`w-full rounded-[22px] py-4 text-lg font-bold disabled:opacity-40 ${tipo === "fiado" ? "bg-destructive text-destructive-foreground" : "bg-success text-paper"}`}
      >
        {tipo === "fiado" ? "Anotar fiado" : "Registrar abono"}
      </button>
      {tipo === "abono" && <p className="text-xs text-muted-foreground">El abono entra a la caja como ingreso.</p>}

      <h3 className="pt-2 text-lg font-semibold">Historial</h3>
      {c.apuntes.length === 0 && <p className="text-sm text-muted-foreground">Sin apuntes todavía.</p>}
      {c.apuntes.map((a) => (
        <div key={a.id} className="flex items-center gap-3">
          <div className={`grid size-9 shrink-0 place-items-center rounded-full text-sm font-bold ${a.tipo === "fiado" ? "bg-destructive/15 text-destructive" : "bg-success/15 text-success"}`}>{a.tipo === "fiado" ? "+" : "–"}</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold">{a.descripcion}</p>
            <p className="text-xs text-muted-foreground">{new Date(a.fecha).toLocaleDateString("es-CO", { day: "numeric", month: "short" })} · {hora(a.fecha)}</p>
          </div>
          <span className={`text-sm font-bold ${a.tipo === "fiado" ? "text-destructive" : "text-success"}`}>{dinero(a.monto)}</span>
          <button aria-label="Borrar" onClick={() => confirm("¿Borrar este apunte?") && acciones.borrarApunte(c.id, a.id)} className="text-muted-foreground">✕</button>
        </div>
      ))}
      <button onClick={() => { if (confirm(`¿Eliminar a ${c.nombre} del cuaderno?`)) { acciones.borrarCliente(c.id); cerrar(); } }} className="w-full pt-4 text-sm font-bold text-destructive">
        Eliminar persona
      </button>
    </Hoja>
  );
}
