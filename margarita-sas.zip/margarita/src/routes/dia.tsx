import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import { ListaMovs, Pantalla } from "@/components/tienda";
import { claveDia, descargarPdf, fechaLarga, movsDelDia } from "@/lib/reporte";
import { dinero, resumen, useStore } from "@/lib/store";

export const Route = createFileRoute("/dia")({
  validateSearch: z.object({ fecha: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() }),
  head: () => ({
    meta: [
      { title: "Reporte del día — margarita.sas" },
      { name: "description", content: "Todo lo que se hizo en el día: ventas, gastos y ganancia. Imprime o descarga en PDF." },
      { property: "og:title", content: "Reporte del día — margarita.sas" },
      { property: "og:description", content: "Imprime o descarga en PDF lo que se hizo en el día." },
    ],
  }),
  component: Dia,
});

function Dia() {
  const { fecha } = Route.useSearch();
  const dia = fecha ?? claveDia(new Date());
  const { negocio, movimientos } = useStore();
  const movs = movsDelDia(movimientos, dia);
  const r = resumen(movs);
  const filas = [
    ["Ventas", r.ventas],
    ["  · en efectivo", r.efectivo],
    ["  · por transferencia", r.transferencias],
    ["Costo de mercancía", -r.costo],
    ["Gastos", -r.gastos],
    ["Retiros", -r.retiros],
    ["Otros ingresos", r.ingresos],
  ] as const;

  return (
    <Pantalla titulo="Reporte del día" sub={`${negocio} · ${fechaLarga(dia)}`}>
      <div className="mt-5 grid grid-cols-2 gap-3 print:hidden">
        <button onClick={() => window.print()} className="rounded-[22px] bg-ink py-4 font-bold text-paper">🖨️ Imprimir</button>
        <button onClick={() => descargarPdf(negocio, dia, movs)} className="rounded-[22px] bg-primary py-4 font-bold text-primary-foreground">📄 Descargar PDF</button>
      </div>
      <Link to="/calendario" className="mt-3 block text-center text-sm font-bold text-primary print:hidden">📅 Ver otro día en el calendario</Link>

      <div className="tile mt-5 p-5">
        {filas.map(([l, v]) => (
          <div key={l} className="flex justify-between py-1.5 text-sm">
            <span className="font-medium">{l}</span>
            <span className="font-bold">{v < 0 ? "–" : ""}{dinero(Math.abs(v))}</span>
          </div>
        ))}
        <div className="mt-2 flex justify-between border-t border-border pt-3">
          <span className="font-display text-lg font-semibold">Ganancia</span>
          <span className={`text-2xl font-extrabold ${r.ganancia >= 0 ? "text-success" : "text-destructive"}`}>{r.ganancia < 0 ? "–" : ""}{dinero(Math.abs(r.ganancia))}</span>
        </div>
        <div className="flex justify-between pt-2 text-sm">
          <span className="font-medium">Efectivo esperado en caja</span>
          <span className="font-bold">{dinero(r.caja)}</span>
        </div>
        <div className="flex justify-between pt-1 text-sm">
          <span className="font-medium">Número de ventas</span>
          <span className="font-bold">{r.tickets}</span>
        </div>
      </div>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Movimientos ({movs.length})</h2>
        <ListaMovs movs={movs} />
      </section>
    </Pantalla>
  );
}
