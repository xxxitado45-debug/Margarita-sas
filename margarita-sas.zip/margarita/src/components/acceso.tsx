import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { tiendaDe, useStore } from "@/lib/store";

const db = () => (supabase as any).from("tienda_acceso");

export function AccesoCompartido() {
  useStore();
  const [lista, setLista] = useState<string[]>([]);
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const propia = tiendaDe?.propia ?? true;

  const cargar = async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { data } = await db().select("email").eq("owner_id", u.user.id).order("created_at");
    setLista((data ?? []).map((r: { email: string }) => r.email));
  };
  useEffect(() => { if (propia) cargar(); }, [propia]);

  if (!propia) return <p className="mt-6 rounded-[16px] bg-muted p-3 text-sm font-medium">Estás encargada de la tienda de otra persona. Ves y anotas en sus datos.</p>;

  const agregar = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg("");
    const { data: u } = await supabase.auth.getUser();
    const correo = email.trim().toLowerCase();
    if (!u.user || !correo) return;
    if (correo === u.user.email?.toLowerCase()) return setMsg("Ese es tu propio correo.");
    const { error } = await db().insert({ owner_id: u.user.id, email: correo });
    if (error) return setMsg("No se pudo agregar (¿ya estaba?).");
    setEmail("");
    cargar();
  };
  const quitar = async (correo: string) => {
    const { data: u } = await supabase.auth.getUser();
    await db().delete().eq("owner_id", u.user!.id).eq("email", correo);
    cargar();
  };

  return (
    <section className="mt-8">
      <h2 className="text-xl font-semibold">Personas encargadas</h2>
      <p className="mt-1 text-sm text-muted-foreground">Agrega su Gmail. Al entrar con Google verán y anotarán en todos tus datos.</p>
      <form onSubmit={agregar} className="mt-3 flex gap-2">
        <input className="field flex-1" type="email" required placeholder="correo@gmail.com" value={email} onChange={(e) => setEmail(e.target.value)} />
        <button className="rounded-[16px] bg-primary px-4 font-bold text-primary-foreground">Agregar</button>
      </form>
      {msg && <p className="mt-2 text-sm font-medium text-destructive">{msg}</p>}
      <div className="mt-3 space-y-2">
        {lista.map((c) => (
          <div key={c} className="tile flex items-center justify-between rounded-[16px] p-3">
            <span className="truncate text-sm font-bold">{c}</span>
            <button onClick={() => quitar(c)} className="text-sm font-bold text-destructive">Quitar</button>
          </div>
        ))}
      </div>
    </section>
  );
}
