import { useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { conectarNube } from "@/lib/store";

export function Sesion({ children }: { children: ReactNode }) {
  const [sesion, setSesion] = useState<Session | null | undefined>(undefined);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSesion(s));
    supabase.auth.getSession().then(({ data }) => setSesion(data.session));
    return () => data.subscription.unsubscribe();
  }, []);

  const uid = sesion?.user.id;
  const correo = sesion?.user.email;
  useEffect(() => {
    if (!uid) return;
    let off: (() => void) | undefined;
    conectarNube(uid, correo).then((f) => (off = f));
    return () => off?.();
  }, [uid, correo]);

  if (sesion === undefined) return <div className="grid min-h-screen place-items-center text-muted-foreground">Cargando…</div>;
  if (!sesion) return <Entrar />;
  return <>{children}</>;
}

function Entrar() {
  const [modo, setModo] = useState<"entrar" | "crear">("entrar");
  const [email, setEmail] = useState("");
  const [clave, setClave] = useState("");
  const [msg, setMsg] = useState("");
  const [cargando, setCargando] = useState(false);

  const enviar = async (e: React.FormEvent) => {
    e.preventDefault();
    setCargando(true);
    setMsg("");
    const r = modo === "entrar"
      ? await supabase.auth.signInWithPassword({ email, password: clave })
      : await supabase.auth.signUp({ email, password: clave, options: { emailRedirectTo: window.location.origin } });
    setCargando(false);
    if (r.error) return setMsg(r.error.message.includes("Invalid") ? "Correo o contraseña incorrectos." : r.error.message);
    if (modo === "crear" && !r.data.session) setMsg("Te enviamos un correo para confirmar tu cuenta. Ábrelo y luego entra aquí.");
  };

  const google = async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) setMsg("No se pudo entrar con Google.");
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-[420px] flex-col justify-center px-5">
      <div className="rounded-[20px] bg-primary p-6 text-primary-foreground">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] opacity-80">Bienvenida a</p>
        <h1 className="text-4xl font-semibold">margarita.sas</h1>
        <p className="mt-2 text-sm opacity-90">Tus ventas, inventario y cuentas guardados en la nube, en todos tus dispositivos.</p>
      </div>
      <form onSubmit={enviar} className="mt-5 space-y-3">
        <input className="field" type="email" required placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className="field" type="password" required minLength={6} placeholder="Contraseña" value={clave} onChange={(e) => setClave(e.target.value)} />
        {msg && <p className="text-sm font-medium text-destructive">{msg}</p>}
        <button disabled={cargando} className="w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-50">
          {modo === "entrar" ? "Entrar" : "Crear cuenta"}
        </button>
      </form>
      <button onClick={google} className="tile mt-3 w-full py-4 font-bold">Continuar con Google</button>
      <button onClick={() => { setModo(modo === "entrar" ? "crear" : "entrar"); setMsg(""); }} className="mt-4 text-sm font-bold text-primary">
        {modo === "entrar" ? "¿No tienes cuenta? Crear una" : "Ya tengo cuenta, entrar"}
      </button>
    </div>
  );
}
