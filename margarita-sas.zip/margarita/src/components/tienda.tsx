import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { acciones, dinero, hora, useStore, type Movimiento } from "@/lib/store";

export function Pantalla({ titulo, sub, children }: { titulo: string; sub?: string; children: ReactNode }) {
  return (
    <div className="mx-auto min-h-screen max-w-[540px] px-5 pb-32 pt-6">
      <p className="text-sm font-medium text-muted-foreground">{sub}</p>
      <h1 className="text-3xl font-semibold leading-none">{titulo}</h1>
      {children}
    </div>
  );
}

const tabs = [
  { to: "/", icon: "🏠", label: "Panel" },
  { to: "/venta", icon: "🛒", label: "Venta" },
  { to: "/inventario", icon: "📦", label: "Inventario" },
  { to: "/caja", icon: "💰", label: "Caja" },
  { to: "/gastos", icon: "📒", label: "Gastos" },
  { to: "/mes", icon: "🗓️", label: "Mes" },
  { to: "/fiado", icon: "🤝", label: "Fiado" },
] as const;

export function BarraNav() {
  return (
    <nav className="print:hidden fixed bottom-0 left-0 right-0 z-20 border-t border-border bg-paper/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[540px] justify-around px-2 py-2">
        {tabs.map((t) => (
          <Link
            key={t.to}
            to={t.to}
            className="flex flex-1 flex-col items-center gap-1 rounded-2xl py-2.5 text-xs font-medium text-muted-foreground"
            activeProps={{ className: "font-bold !text-primary" }}
            activeOptions={{ exact: true }}
          >
            <span className="text-lg leading-none">{t.icon}</span>
            {t.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}

export function VentaRapida({ limite }: { limite?: number }) {
  const { productos } = useStore();
  const [carrito, setCarrito] = useState<Record<string, number>>({});
  const [ok, setOk] = useState(false);
  const lista = limite ? productos.filter((p) => p.stock > 0).slice(0, limite) : productos;
  const total = productos.reduce((s, p) => s + (carrito[p.id] ?? 0) * p.precio, 0);
  const [pago, setPago] = useState<"efectivo" | "transferencia">("efectivo");
  const add = (id: string, d: number) =>
    setCarrito((c) => {
      const p = productos.find((x) => x.id === id)!;
      const q = Math.min(p.stock, Math.max(0, (c[id] ?? 0) + d));
      return { ...c, [id]: q };
    });

  return (
    <div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {lista.map((p) => {
          const q = carrito[p.id] ?? 0;
          return (
            <div key={p.id} className={`tile relative p-4 ${q ? "ring-2 ring-primary" : ""} ${p.stock === 0 ? "opacity-50" : ""}`}>
              <button className="w-full text-left" disabled={p.stock === 0} onClick={() => add(p.id, 1)}>
                <p className="text-2xl leading-none">{p.emoji}</p>
                <p className="mt-3 text-base font-bold leading-tight">{p.nombre}</p>
                <p className="mt-1 text-sm font-medium text-success">{dinero(p.precio)}</p>
                <p className="text-xs text-muted-foreground">{p.stock === 0 ? "Agotado" : `${p.stock} en stock`}</p>
              </button>
              {q > 0 && (
                <div className="absolute right-3 top-3 flex items-center gap-1">
                  <button onClick={() => add(p.id, -1)} className="grid size-7 place-items-center rounded-full bg-secondary font-bold">−</button>
                  <span className="grid size-7 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{q}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-[22px] bg-ink px-5 py-4">
        <span className="text-sm font-medium text-paper/70">Total</span>
        <span className="text-2xl font-extrabold leading-none text-paper">{dinero(total)}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {([["efectivo", "💵 Efectivo"], ["transferencia", "📲 Transferencia"]] as const).map(([v, l]) => (
          <button key={v} onClick={() => setPago(v)} className={`rounded-[18px] py-3 text-base font-bold ${pago === v ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{l}</button>
        ))}
      </div>
      <button
        disabled={!total}
        onClick={() => {
          acciones.vender(pago, carrito);
          setCarrito({});
          setOk(true);
          setTimeout(() => setOk(false), 1800);
        }}
        className="mt-3 w-full rounded-[22px] bg-success py-4 text-lg font-bold text-paper disabled:opacity-40"
      >
        {ok ? "✓ Venta registrada" : "Cobrar venta"}
      </button>
    </div>
  );
}

const estilo = {
  venta: { s: "+", c: "bg-success/15 text-success", t: "text-success" },
  ingreso: { s: "+", c: "bg-success/15 text-success", t: "text-success" },
  gasto: { s: "–", c: "bg-destructive/15 text-destructive", t: "text-destructive" },
  retiro: { s: "↔", c: "bg-accent/25 text-wood", t: "text-wood" },
};

export function ListaMovs({ movs, borrar }: { movs: Movimiento[]; borrar?: boolean }) {
  if (!movs.length) return <p className="mt-4 text-sm text-muted-foreground">Aún no hay movimientos.</p>;
  return (
    <div className="mt-4 space-y-2.5">
      {movs.map((m) => {
        const e = estilo[m.tipo];
        const pos = m.tipo === "venta" || m.tipo === "ingreso";
        return (
          <div key={m.id} className="flex items-center gap-3">
            <div className={`grid size-9 shrink-0 place-items-center rounded-full text-sm font-bold ${e.c}`}>{e.s}</div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold leading-tight">{m.descripcion}</p>
              <p className="text-xs font-medium text-muted-foreground">
                {new Date(m.fecha).toLocaleDateString("es-CO", { day: "numeric", month: "short" })} · {hora(m.fecha)}{m.pago ? (m.pago === "transferencia" ? " · 📲 Transferencia" : " · 💵 Efectivo") : ""}
              </p>
            </div>
            <span className={`text-sm font-bold ${e.t}`}>{pos ? "+" : "–"}{dinero(m.monto)}</span>
            {borrar && (
              <button
                aria-label="Borrar"
                onClick={() => confirm("¿Borrar este movimiento?") && acciones.borrarMovimiento(m.id)}
                className="text-muted-foreground"
              >
                ✕
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
