<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Shop data is one JSON document per owner in `tienda_estado`, synced from `src/lib/store.ts` (localStorage cache + debounced upsert + realtime). Why: simple whole-state sync across devices for a single small shop.
- Helpers listed by email in `tienda_acceso` load and edit the owner's document (RLS via `puede_ver_tienda`). Why: the owner can hand the shop to someone else without sharing a password.
- The whole app is signed-in only, gated by `Sesion` in `__root.tsx` (inline login instead of routes). Why: every screen is private shop data.
